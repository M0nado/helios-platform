"""Read-only-source checks; all generated fleet state stays in temporary folders."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import uuid

SOURCE=Path(__file__).parent/'source/src/ai/python/helios_agents/fleet_learning.py'
spec=importlib.util.spec_from_file_location('reviewed_fleet_learning', SOURCE)
fleet=importlib.util.module_from_spec(spec)
spec.loader.exec_module(fleet)

class FleetIdentityChecks(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.run=self.root/'run'; (self.run/'boards').mkdir(parents=True)
        (self.run/'manifest.json').write_text(json.dumps({'runId':'fixture-run','pools':[{'board':'dev','pool':'hermes'}]}))
        (self.run/'boards/dev.json').write_text(json.dumps({'board':'dev','tasks':[{'id':'task-1','lane':'code_review','status':'done','claimedAt':'2026-09-05T12:00:00Z','finishedAt':'2026-09-05T12:00:01Z'}]}))
        self.output=self.root/'outcomes.jsonl'
    def record(self):
        fleet.collect(self.run,self.output)
        return json.loads(self.output.read_text().splitlines()[0])
    def test_deterministic_expected_uuid(self):
        self.assertEqual(self.record()['outcomeId'],str(uuid.uuid5(uuid.NAMESPACE_URL,'helios:fleet:fixture-run:dev:task-1')))
    def test_retry_does_not_append_duplicate(self):
        self.record(); again=fleet.collect(self.run,self.output)
        self.assertEqual(again['collected'],0)
        self.assertEqual(len(self.output.read_text().splitlines()),1)
    def test_separate_output_store_gets_same_identity(self):
        first=self.record(); other=self.root/'other.jsonl'
        fleet.collect(self.run,other)
        self.assertEqual(json.loads(other.read_text())['outcomeId'], first['outcomeId'])
    def test_keeps_advisory_provenance_and_no_invented_spend(self):
        record=self.record()
        self.assertEqual(record['source'],'fleet-lane')
        self.assertEqual(record['costUsd'],0.0)
        self.assertIsNone(record['quality'])
        self.assertEqual(record['latencyMs'],1000.0)

if __name__=='__main__':
    unittest.main(verbosity=2)
